@extends('_layout/_admin/_base')
@section('content')
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Rem a, odio odit quas facere porro eos
                repellendus in similique sunt debitis quos, facilis eligendi ab sed voluptas! Quibusdam, sint maxime.
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
@endsection