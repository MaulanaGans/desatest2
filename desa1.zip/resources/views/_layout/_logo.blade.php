<b class="logo-icon">
    <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
    <!-- Dark Logo icon -->
    <img src="/dashboard_assets/assets/images/logo-icon.png" alt="homepage" class="dark-logo" />
    <!-- Light Logo icon -->
    <img src="/dashboard_assets/assets/images/logo-icon.png" alt="homepage" class="light-logo" />
</b>
<!--End Logo icon -->
<!-- Logo text -->
<span class="logo-text">
    <!-- dark Logo text -->
    <img src="/dashboard_assets/assets/images/logo-text.png" alt="homepage" class="dark-logo" />
    <!-- Light Logo text -->
    <img src="/dashboard_assets/assets/images/logo-light-text.png" class="light-logo" alt="homepage" />
</span>